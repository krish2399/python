def customer_contact():
    print("123456789")
